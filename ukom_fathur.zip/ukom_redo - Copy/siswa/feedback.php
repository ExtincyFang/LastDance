<?php
session_start();
include "../includes/koneksi.php"; // sesuaikan path

if (!isset($_SESSION['id_user'])) {
    header("Location: ../login.php");
    exit;
}

$id_user = $_SESSION['id_user'];
$id_aspirasi = $_GET['id'] ?? null;

if (!$id_aspirasi) {
    echo "ID aspirasi tidak ditemukan";
    exit;
}

// Kirim feedback
if (isset($_POST['kirim'])) {
    $isi = htmlspecialchars($_POST['isi_feedback']);

    $query = mysqli_query($koneksi, "INSERT INTO tb_feedback (id_user, id_aspirasi, isi_feedback) VALUES ('$id_user', '$id_aspirasi', '$isi')");
}

$sql = "SELECT f.*, u.nama, u.role 
        FROM tb_feedback f 
        JOIN tb_user u ON f.id_user = u.id_user 
        WHERE f.id_aspirasi = '$id_aspirasi'
        ORDER BY f.created_at ASC";

$chat = mysqli_query($koneksi, $sql);

if (!$chat) {
    die("Query Error: " . mysqli_error($koneksi));
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Feedback Chat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .chat-box { max-height: 70vh; overflow-y: auto; }
        .chat-bubble { padding: 10px 15px; border-radius: 15px; margin-bottom: 8px; max-width: 70%; }
        .me { background: #0d6efd; color: white; margin-left: auto; }
        .other { background: #f1f1f1; }
        .chat-name { font-size: 12px; opacity: 0.7; }
    </style>
</head>
<body class="bg-light">

<div class="container py-4 mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <b>Feedback Chat Aspirasi #<?= $id_aspirasi ?></b>
        </div>

        <div class="card-body chat-box" id="chatBox">
            <?php while($d = mysqli_fetch_assoc($chat)): ?>
                <div class="d-flex flex-column <?= ($d['id_user'] == $id_user) ? 'align-items-end' : 'align-items-start' ?>">
                    <div class="chat-bubble <?= ($d['id_user'] == $id_user) ? 'me' : 'other' ?>">
                        <div class="chat-name">
                            <?= htmlspecialchars($d['nama']) ?> (<?= $d['role'] ?>)
                        </div>
                        <?= htmlspecialchars($d['isi_feedback']) ?>
                        <div style="font-size:11px; opacity:0.6;">
                            <?= $d['created_at'] ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

        <div class="card-footer">
            <form method="POST" class="d-flex gap-2">
                <input type="text" name="isi_feedback" class="form-control" placeholder="Tulis pesan..." required>
                <button type="submit" name="kirim" class="btn btn-primary">Kirim</button>
            </form>
        </div>
    </div>
</div>

<script>
    // Auto scroll ke bawah
    let chatBox = document.getElementById('chatBox');
    chatBox.scrollTop = chatBox.scrollHeight;
</script>

</body>
</html>